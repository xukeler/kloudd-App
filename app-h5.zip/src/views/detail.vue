<template>
    <div class="requirement-list-detail-box">
        <div class="detail-header-container">
            <div class="back-icon">
                <span class="icon icon-leftarrow"></span>
            </div>
            <div class="detail-title">
                11567- Sprint summary 
            </div>
            <div class="detail-owner">
               <span> Owner: James</span>
            </div>
        </div>
        <div class="detail-body">
            <div class="detail-description">
                Description text Description text Description text Description text Description text Description textDescription text Description text Description 
            </div>
            <div class="develop-time">
                Time Estimate changed from “3 days 12 hours” to “4 days 10 hours”
            </div>
            <div class="message-hint">
                This requirment requires your approval
            </div>
            <div class="approve-btn">
                <a>approve</a>
            </div>
            <div class="reject-btn">
                <a>reject</a>
            </div>
            <div class="text">
                Approval Request , A new change is added
            </div>
        </div>
        
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss">

</style>