<template>
    <div class="requirement-list-box">
        <p class="approval-title">Approval request summary</p>
        <div class="adorn-img">
          <img src="../assets/images/adorn-img.png" alt="">
        </div>
        <div class="requirement-content-box">
            <div class="all-title">The title</div>
            <div class="all-description">
                Description text Description text Description text Description text Description text Description textDescription text Description text Description 
            </div>
            <div class="hint-message">
                该批列表需要8月底完成，需要双方确认，预计计划9月底开始开发实现。
            </div>
            <div class="requirement-list-title-box">
                <div class="requirement-title">
                    Requirment list
                </div>
                <div class="all-state">
                  <p>
                    <span class="state-num">8</span> Approved
                    <span class="state-line">|</span>
                    <span class="state-num">8</span> rejected
                    <span class="state-line">|</span>
                    <span class="state-num">8</span> pending
                  </p>
                </div>
            </div>
            <div class="requirement-list-data-box">
              <div class="data-box" v-for="y in 3" :key="y">
                <div class="title">【烽火一期-招标文件遗留】自动分配</div>
                <div class="list-state-box">
                  <span class="message">35355-33</span>
                  <span class="state">Approved</span>
                </div>
                <div class="file-list-box">
                  <div class="file-data" v-for="x in 3" :key="x">
                    <div class="file-img">
                      <img src="" alt="">
                    </div>
                    <div class="file-title">
                      Not All Blank Cassettes Are Created Equal.pdf
                    </div>
                    <div class="file-sync">
                      <span class="icon icon-sync"></span>1999
                    </div>
                  </div>
                </div>

              </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return {

            }
        },
        created(){
            let param={
                itemID:188488
            }

            this.$api.getRequirementList(param).then((res)=>{
                console.log(res)
            })
        }
    }
</script>

<style lang="scss" scoped>
    
</style>