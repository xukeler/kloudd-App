let testUrl="https://api.peertime.cn/peertime/V1/";
const url={
   getRequirementList:testUrl+"SyncRoom/Item"
};
export default url