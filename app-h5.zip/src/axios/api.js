import url from './url.js';
import {
    get,
    post,

  } from './axios';
  export default{
    getRequirementList(params){
        return get(url.getRequirementList,params)
    }
   

  }